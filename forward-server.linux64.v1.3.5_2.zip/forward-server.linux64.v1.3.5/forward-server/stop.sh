#!/bin/sh

kill `cat app.pid`
rm -rf app.pid


